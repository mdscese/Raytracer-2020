// TO DO: implement a way to create scene files
// TO DO: implement a way to use a debuging mode an make objects in a scene that way
// TO DO: implement a way to import models into a scene
// TO DO: implement a way to compress the files
